Exercise 01: print_groups
Turn-in directory : ex01/
Files to turn in : print_groups.sh
Allowed functions : None

Write a command line that will display the list of groups for which the login, contained in the environment variable FT_USER , is a member. Separated by commas without spaces.
• Examples :
◦ for FT_USER=nours, the result is "god,root,admin,master,nours,bocal" (with-
out quotation marks)
$>./print_groups.sh
god,root,admin,master,nours,bocal$>
◦ for FT_USER=daemon, the result is "daemon,bin" (without quotation marks)
$>./print_groups.sh
daemon,bin$>
man id
Get inspired by others, do not let them do your job.

Answer: groups $FT_USER | tr ' ' ',' 

// used groups to show groups that ft_user is a member | used de tr to replace the space for a comma. //


Exercise 02: find_sh
Turn-in directory : ex02/
Files to turn in : find_sh.sh
Allowed functions : None
• Write a command line that searches for all file names that end with ".sh" (without
quotation marks) in the current directory and all its sub-directories. It should
display only the file names without the .sh.
• Example of output :
$>./find_sh.sh | cat -e
find_sh$
file1$
file2$
file3$
$>

Answer: find . -iname "*.sh" -printf "%f\n" | sed 's#[.][^.]*$##' 

// used command find apointed to . directory plus -iname to get "*.sh" files, printf to output the files and \n to break line, command sed to not show after the dot or extensions. //

Exercise 03: count_files
Turn-in directory : ex03/
Files to turn in : count_files.sh
Allowed functions : None
• Write a command line that counts and displays the number of regular files and
directories in the current directory and all its sub-directories. It should include ".",
the starting directory.
• Example of output :
$>./count_files.sh | cat -e
42$
$>

Answer: find . | wc -l
// command find apointed to . directory wc -l to word count lines //


Exercise 04: MAC
Turn-in directory : ex04/
Files to turn in : MAC.sh
Allowed functions : None
• Write a command line that displays your machine’s MAC addresses. Each address
must be followed by a line break


Answer: ifconfig -a | grep 'ether' | tr -s ' ' '\t' | cut -f 3
// ifconfig to show all address command grep to match ether lines and tr to replace spaces for tabulation and then cut -f 3 to only show field 3 


Exercise 05: Can you create it ?
Can you create it ?
Turn-in directory : ex05/
Files to turn in : "\?$*'MaRViN'*$?\"
Allowed functions : None
• Create a file containing only "42", and NOTHING else.
• Its name will be :
"\?$*'MaRViN'*$?\"
• Example :
$>ls -lRa *MaRV* | cat -e
-rw---xr-- 1 75355 32015 2 Oct 2 12:21 "\?$*'MaRViN'*$?\"$
$>

Answer: // just add a / before the special character. //




