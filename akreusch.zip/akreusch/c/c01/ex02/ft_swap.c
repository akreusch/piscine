/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 10:46:38 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/10 16:14:01 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

/*int	main(void)
{
	int	num1;
	int	num2;

	num1 = 42;
	num2 = 43;
	ft_swap(&num1, &num2);
	printf("The value of 'a' is: %i, and the value of 'b' is: %i.", num1, num2);
}*/
