/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 15:44:21 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/10 15:54:04 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	div;
	int	rem;

	div = *a;
	rem = *b;
	*a = div / rem;
	*b = div % rem;
}

/*int	main(void)
{
	int	a;
	int	b;

	a = 15;
	b = 2;
	printf("a: %i, b: %i.\n", a, b);
	ft_ultimate_div_mod(&a, &b);
	printf("a: %i, b: %i.", a, b);
}*/
