/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/05 09:57:44 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/09 18:15:38 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_reverse_alphabet(void)
{
	int	num;

	num = 'z';
	while (num >= 'a')
	{
		write(1, &num, 1);
		num--;
	}
}

/*int	main(void)
{
	ft_print_reverse_alphabet();
}*/
