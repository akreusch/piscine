/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 00:20:15 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/12 13:08:23 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char    *ft_strupcase(char *str)
{
    int i;

    i = 0;
    while (str[i] != '\0')
    {
        if (str[i] >= 97 && str[i] <= 122)
        {
            (str[i] -= 32);
        } 
        i++;   
    }
    return(str);
}

/*int main ()
{
    char str1[] = "Hello World";
    char str2[] = "hello world";
    
    printf("%s.\n", str1);
    printf("%s.\n", ft_strupcase(str1));     
    printf("\n%s.\n", str2);
    printf("%s.\n", ft_strupcase(str2));
}*/