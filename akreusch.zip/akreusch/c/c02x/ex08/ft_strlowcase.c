/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 12:02:14 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/12 13:08:21 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char *ft_strlowcase(char *str)
{
    int i;

    i = 0;
    while (str[i] != '\0')
    {
        if (str[i] >= 65 && str[i] <= 90)
        {
            (str[i] += 32);
        }
        i++;
    }
    return(str);
    
}

/*int main()
{
    char str1[] = "HELLO WORLD";
    char str2[] = "Hello World";

    printf("%s.\n", str1);
    printf("%s.\n", ft_strlowcase(str1));     
    printf("\n%s.\n", str2);
    printf("%s.\n", ft_strlowcase(str2)); 
}*/