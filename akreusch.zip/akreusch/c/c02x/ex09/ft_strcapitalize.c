/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 13:13:00 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/12 13:56:52 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char *ft_strcapitalize(char *str)
{
    int i;

    i = 0;
    while (str[i])
    {
        while (!((str[i] >= 97 && str[1] <= 122) || (str[i] >= 65 && str[i] <= 90)))
        i++;

        if (0 == i)
        {
            (str[i] >= 65 && str[i] <= 90)
            str[i] -= 32;
            i++;
        }
        else
            {
                (str[i] >= 97 && str[1] <= 122)
                str[i] += 32;
                i++;
            }
        
    }
}

int main()
{
    char str1[] = "hello world";
    char str2[] = "hELLo wORLd";

    printf("%s.\n", str1);
    printf("%s.\n", ft_strcapitalize(str1));     
    printf("\n%s.\n", str2);
    printf("%s.\n", ft_strcapitalize(str2));  
}
