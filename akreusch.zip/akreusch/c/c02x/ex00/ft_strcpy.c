/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 09:57:18 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/11 09:57:18 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*ft_strcpy(char *dest, char *src)
{
    char *c = dest;
    while ((*c = *src) != '\0') {
        c++;
        src++;
    }
    return dest;
}

/*int		main(void)
{
	char ms[52];
    char *mt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    ft_strcpy(ms, mt);
    printf("%s\n", ms);
    printf("%s\n", mt);
    return 0;
}*/