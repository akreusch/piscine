/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 22:36:08 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/12 11:33:39 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_str_is_numeric(char *str)
{
    if (*str == '\0')
    {
        return 1;
    }
    while (*str != '\0')
    {
        if (*str < 48 || *str > 57)   // 48 = 0 | 57 = 9 //
        {
            return 0;
        }
        else
            {
                return 1;
            }
    str++;        
    }
}   

/*int     main()
{
    char str1[] = "HelloWorld";
    char str2[] = "123456";
    char str3[] = "";
    
    printf("result of teste1 %s is: %i\n", str1, ft_str_is_numeric(str1));
    printf("result of teste2 %s is: %i\n", str2, ft_str_is_numeric(str2));
    printf("result of teste3 %s is: %i\n", str3, ft_str_is_numeric(str3));

    return 0;
}*/