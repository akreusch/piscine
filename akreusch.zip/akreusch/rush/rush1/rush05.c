/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush05.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 12:22:20 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/08 16:48:11 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char value)
{
	write(1, &value, 1);
}

void	rush_last(int x)
{
	int	widthcounter;
	int	widthcond;

	widthcounter = 0;
	widthcond = x - 2;
	ft_putchar('C');
	while (widthcounter < widthcond)
	{
		ft_putchar('B');
		widthcounter++;
	}
	if (x > 1)
		ft_putchar('A');
	ft_putchar('\n');
}

void	rush_middle(int x, int y, int z)
{
	int	middleheightcounter;
	int	middlewidhtcounter;
	int	middleheigthcond;

	middleheightcounter = 0;
	middleheigthcond = y - 2;
	while (middleheightcounter < middleheigthcond)
	{
		middlewidhtcounter = 0;
		ft_putchar('B');
		while (middlewidhtcounter < z)
		{
			ft_putchar(' ');
			middlewidhtcounter++;
		}
		if (x > 1)
			ft_putchar('B');
		ft_putchar('\n');
		middleheightcounter++;
	}
}

void	rush(int x, int y)
{
	int	widthcounter;
	int	widthcond;

	widthcounter = 0;
	widthcond = x - 2;
	if (x <= 0 || y <= 0)
	{
		write(1, "The number of rows and columns must be bigger than 0.\n", 54);
		return ;
	}
	ft_putchar('A');
	while (widthcounter < widthcond)
	{
		ft_putchar('B');
		widthcounter++;
	}
	if (x > 1)
		ft_putchar('C');
	ft_putchar('\n');
	if (y > 2)
		rush_middle(x, y, widthcond);
	if (y > 1)
		rush_last(x);
}

int	main(void)
{
	rush (5, 3);
	rush (5, 1);
	rush (1, 1);
	rush (1, 5);
	rush (4, 4);
	rush (0, 4);
	rush (4, 0);
	rush (0, 0);
	rush (-1, 4);
	rush (4, -1);
	return (0);
}
