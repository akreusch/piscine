/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 19:51:38 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/12 15:10:34 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	int	i;
	int	r;
	int	c;

	i = 0;
	r = 1;
	while (*(str + i) != '\0')
	{
		c = *(str + i);
		if (c < 65 || (c > 90 && c < 97) || c > 122)
		{
			r = 0;
		}
		i++;
	}
	return (r);
}

/*int     main()
{
    char str1[] = "HelloWorld";
    char str2[] = "123456";
    char str3[] = "";
    
    printf("result of teste1 %s is: %i\n", str1, ft_str_is_alpha(str1));
    printf("result of teste2 %s is: %i\n", str2, ft_str_is_alpha(str2));
    printf("result of teste3 %s is: %i\n", str3, ft_str_is_alpha(str3));

    return 0;
}*/
