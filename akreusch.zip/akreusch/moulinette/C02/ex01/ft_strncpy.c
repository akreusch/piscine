/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 17:57:25 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/12 15:04:43 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && src[i])
	{
		dest[i] = src[i];
		i++;
	}
	if (n > i)
	{
		dest[i] = '\0';
	}
	return (dest);
}

/*int main(void)
{
    char src[] = "Hello";
    char dest [27] = "world1";

    ft_strncpy(dest, src, 5);
    printf("From where came this text? %s", dest);
}*/
