/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akreusch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 00:00:41 by akreusch          #+#    #+#             */
/*   Updated: 2024/09/12 15:29:16 by akreusch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	if (*str == '\0')
		return (1);
	while (*str != '\0')
	{
		if (*str >= 32 && *str <= 126)
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

/*int     main()
{
    char str1[] = "HELLOWORLD";
    char str2[] = "Hello World";
    char str3[] = "123456";
    char str4[] = "&ç * . *+-,";
    char str5[] = "";

    printf("result of teste1 %s is: %i\n", str1, ft_str_is_printable(str1));
    printf("result of teste2 %s is: %i\n", str2, ft_str_is_printable(str2));
    printf("result of teste3 %s is: %i\n", str3, ft_str_is_printable(str3));
    printf("result of teste4 %s is: %i\n", str4, ft_str_is_printable(str4));
    printf("result of teste5 %s is: %i\n", str5, ft_str_is_printable(str5));    
}*/
